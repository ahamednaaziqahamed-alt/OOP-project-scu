package medicare.model;

public class Doctor {

    private String doctorId;
    private String name;
    private String speciality;
    private String phone;
    private String email;

    public Doctor() {}

    public Doctor(String doctorId, String name, String speciality, String phone, String email) {
        this.doctorId = doctorId;
        this.name = name;
        this.speciality = speciality;
        this.phone = phone;
        this.email = email;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
