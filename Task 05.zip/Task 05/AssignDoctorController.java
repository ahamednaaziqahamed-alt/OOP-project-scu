package medicare.controller;

import medicare.model.*;
import medicare.store.DataStore;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AssignDoctorController {

    // Find doctors by speciality (exact match)
    public List<Doctor> getDoctorsBySpeciality(String speciality) {
        List<Doctor> out = new ArrayList<>();
        if (speciality == null) return out;

        for (Doctor d : DataStore.doctors) {
            if (speciality.equalsIgnoreCase(d.getSpeciality())) out.add(d);
        }
        return out;
    }

    // Simple availability check: no appointment conflict at that date/time
    public boolean isDoctorAvailable(String doctorId, LocalDate date, LocalTime time) {
        if (doctorId == null || date == null || time == null) return false;

        for (Appointment a : DataStore.appointments) {
            if (doctorId.equals(a.getDoctorId())
                    && date.equals(a.getDate())
                    && time.equals(a.getTime())
                    && a.getStatus() != AppointmentStatus.CANCELLED) {
                return false;
            }
        }
        return true;
    }

    // Auto-assign: first available doctor from given speciality, optionally earliest by "doctorId" as stable sort
    public Doctor autoAssignDoctor(String speciality, LocalDate date, LocalTime time) {
        List<Doctor> candidates = getDoctorsBySpeciality(speciality);
        candidates.sort(Comparator.comparing(Doctor::getDoctorId));

        for (Doctor d : candidates) {
            if (isDoctorAvailable(d.getDoctorId(), date, time)) return d;
        }
        return null;
    }
}
