package medicare.controller;

import medicare.model.Patient;
import medicare.store.DataStore;

import java.util.ArrayList;
import java.util.List;

public class PatientController {

    public List<Patient> getAllPatients() {
        return new ArrayList<>(DataStore.patients);
    }

    public Patient findById(String patientId) {
        if (patientId == null) return null;
        for (Patient p : DataStore.patients) {
            if (patientId.equals(p.getPatientId())) return p;
        }
        return null;
    }

    public void addPatient(Patient patient) {
        if (patient == null) throw new IllegalArgumentException("Patient is required");
        validatePatient(patient);

        if (findById(patient.getPatientId()) != null) {
            throw new IllegalStateException("Patient ID already exists");
        }
        DataStore.patients.add(patient);
    }

    public void updatePatient(Patient updated) {
        if (updated == null) throw new IllegalArgumentException("Patient is required");
        validatePatient(updated);

        Patient existing = findById(updated.getPatientId());
        if (existing == null) throw new IllegalStateException("Patient not found");

        existing.setName(updated.getName());
        existing.setNic(updated.getNic());
        existing.setPhone(updated.getPhone());
        existing.setEmail(updated.getEmail());
        existing.setAddress(updated.getAddress());
    }

    public void deletePatient(String patientId) {
        Patient existing = findById(patientId);
        if (existing == null) throw new IllegalStateException("Patient not found");
        DataStore.patients.remove(existing);
    }

    private void validatePatient(Patient p) {
        if (isBlank(p.getPatientId())) throw new IllegalArgumentException("Patient ID required");
        if (isBlank(p.getName())) throw new IllegalArgumentException("Patient name required");
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
