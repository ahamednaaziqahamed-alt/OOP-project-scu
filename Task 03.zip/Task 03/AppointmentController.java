package medicare.controller;

import medicare.model.*;
import medicare.store.DataStore;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class AppointmentController {

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(DataStore.appointments);
    }

    public Appointment findById(String appointmentId) {
        if (appointmentId == null) return null;
        for (Appointment a : DataStore.appointments) {
            if (appointmentId.equals(a.getAppointmentId())) return a;
        }
        return null;
    }

    public void scheduleAppointment(Appointment appointment) {
        if (appointment == null) throw new IllegalArgumentException("Appointment is required");
        validateAppointment(appointment);

        // Conflict check: same doctor, same date, same time, not cancelled
        for (Appointment a : DataStore.appointments) {
            if (a.getDoctorId().equals(appointment.getDoctorId())
                    && a.getDate().equals(appointment.getDate())
                    && a.getTime().equals(appointment.getTime())
                    && a.getStatus() != AppointmentStatus.CANCELLED) {
                throw new IllegalStateException("Doctor already has an appointment at this time");
            }
        }

        // Default status if missing
        if (appointment.getStatus() == null) {
            appointment.setStatus(AppointmentStatus.SCHEDULED);
        }

        DataStore.appointments.add(appointment);
    }

    public void updateAppointment(Appointment updated) {
        if (updated == null) throw new IllegalArgumentException("Appointment is required");
        validateAppointment(updated);

        Appointment existing = findById(updated.getAppointmentId());
        if (existing == null) throw new IllegalStateException("Appointment not found");

        // Conflict check excluding itself
        for (Appointment a : DataStore.appointments) {
            if (!a.getAppointmentId().equals(updated.getAppointmentId())
                    && a.getDoctorId().equals(updated.getDoctorId())
                    && a.getDate().equals(updated.getDate())
                    && a.getTime().equals(updated.getTime())
                    && a.getStatus() != AppointmentStatus.CANCELLED) {
                throw new IllegalStateException("Doctor already has an appointment at this time");
            }
        }

        existing.setPatientId(updated.getPatientId());
        existing.setDoctorId(updated.getDoctorId());
        existing.setDate(updated.getDate());
        existing.setTime(updated.getTime());
        existing.setReason(updated.getReason());
        existing.setStatus(updated.getStatus());
        existing.setRemarks(updated.getRemarks());
    }

    public void cancelAppointment(String appointmentId, String remarks) {
        Appointment existing = findById(appointmentId);
        if (existing == null) throw new IllegalStateException("Appointment not found");
        existing.setStatus(AppointmentStatus.CANCELLED);
        existing.setRemarks(remarks);
    }

    public void deleteAppointment(String appointmentId) {
        Appointment existing = findById(appointmentId);
        if (existing == null) throw new IllegalStateException("Appointment not found");
        DataStore.appointments.remove(existing);
    }

    public List<Appointment> getAppointmentsByDate(LocalDate date) {
        List<Appointment> out = new ArrayList<>();
        if (date == null) return out;
        for (Appointment a : DataStore.appointments) {
            if (date.equals(a.getDate())) out.add(a);
        }
        return out;
    }

    public List<Appointment> getAppointmentsByDoctor(String doctorId) {
        List<Appointment> out = new ArrayList<>();
        if (doctorId == null) return out;
        for (Appointment a : DataStore.appointments) {
            if (doctorId.equals(a.getDoctorId())) out.add(a);
        }
        return out;
    }

    private void validateAppointment(Appointment a) {
        if (isBlank(a.getAppointmentId())) throw new IllegalArgumentException("Appointment ID required");
        if (isBlank(a.getPatientId())) throw new IllegalArgumentException("Patient required");
        if (isBlank(a.getDoctorId())) throw new IllegalArgumentException("Doctor required");
        LocalDate d = a.getDate();
        LocalTime t = a.getTime();
        if (d == null) throw new IllegalArgumentException("Date required");
        if (t == null) throw new IllegalArgumentException("Time required");
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
