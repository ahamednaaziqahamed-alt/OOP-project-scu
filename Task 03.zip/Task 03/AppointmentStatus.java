
package medicare.model;

public enum AppointmentStatus {
    SCHEDULED,
    COMPLETED,
    CANCELLED,
    DELAYED
}
