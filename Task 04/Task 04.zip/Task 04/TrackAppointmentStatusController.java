package medicare.controller;

import medicare.model.Appointment;
import medicare.model.AppointmentStatus;
import medicare.store.DataStore;

import java.util.ArrayList;
import java.util.List;

public class TrackAppointmentStatusController {

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(DataStore.appointments);
    }

    public Appointment loadAppointment(String appointmentId) {
        if (appointmentId == null) return null;
        for (Appointment a : DataStore.appointments) {
            if (appointmentId.equals(a.getAppointmentId())) return a;
        }
        return null;
    }

    public void updateStatus(String appointmentId, AppointmentStatus newStatus, String remarks) {
        if (newStatus == null) throw new IllegalArgumentException("Status required");

        Appointment a = loadAppointment(appointmentId);
        if (a == null) throw new IllegalStateException("Appointment not found");

        a.setStatus(newStatus);
        a.setRemarks(remarks);
    }

    public void deleteAppointment(String appointmentId) {
        Appointment a = loadAppointment(appointmentId);
        if (a == null) throw new IllegalStateException("Appointment not found");
        DataStore.appointments.remove(a);
    }
}
