
package medicare.app;

import medicare.model.Doctor;
import medicare.model.Patient;
import medicare.store.DataStore;

public final class SeedData {

    private static boolean seeded = false;

    private SeedData() {}

    public static void seedOnce() {
        if (seeded) return;
        seeded = true;

        // Patients
        DataStore.patients.add(new Patient("P001", "Alice Perera", "200012345678", "0771234567", "alice@mail.com", "Colombo"));
        DataStore.patients.add(new Patient("P002", "Kamal Silva", "199945678901", "0712345678", "kamal@mail.com", "Kandy"));

        // Doctors
        DataStore.doctors.add(new Doctor("D001", "Dr. Fernando", "Cardiology", "0779988776", "fernando@hospital.com"));
        DataStore.doctors.add(new Doctor("D002", "Dr. Nimal", "Dermatology", "0711122233", "nimal@hospital.com"));
    }
}
