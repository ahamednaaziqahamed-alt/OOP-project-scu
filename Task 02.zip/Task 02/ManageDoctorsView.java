
package medicare.view;

import medicare.controller.DoctorController;
import medicare.model.Doctor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ManageDoctorsView extends JFrame {

    private final DoctorController doctorController = new DoctorController();

    private final JTextField txtId = new JTextField();
    private final JTextField txtName = new JTextField();
    private final JTextField txtSpeciality = new JTextField();
    private final JTextField txtPhone = new JTextField();
    private final JTextField txtEmail = new JTextField();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Doctor ID", "Name", "Speciality", "Phone", "Email"}, 0
    );
    private final JTable table = new JTable(tableModel);

    public ManageDoctorsView() {
        setTitle("Manage Doctors");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Doctor Details"));

        form.add(new JLabel("Doctor ID"));
        form.add(txtId);
        form.add(new JLabel("Name"));
        form.add(txtName);
        form.add(new JLabel("Speciality"));
        form.add(txtSpeciality);
        form.add(new JLabel("Phone"));
        form.add(txtPhone);
        form.add(new JLabel("Email"));
        form.add(txtEmail);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");
        JButton btnBack = new JButton("Back");

        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        buttons.add(btnBack);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Doctors List"));

        btnAdd.addActionListener(e -> {
            try {
                Doctor d = readDoctorFromForm();
                doctorController.addDoctor(d);
                refreshTable();
                clearForm();
                info("Doctor added.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                Doctor d = readDoctorFromForm();
                doctorController.updateDoctor(d);
                refreshTable();
                info("Doctor updated.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                String id = txtId.getText().trim();
                doctorController.deleteDoctor(id);
                refreshTable();
                clearForm();
                info("Doctor deleted.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnClear.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                txtName.setText(String.valueOf(tableModel.getValueAt(r, 1)));
                txtSpeciality.setText(String.valueOf(tableModel.getValueAt(r, 2)));
                txtPhone.setText(String.valueOf(tableModel.getValueAt(r, 3)));
                txtEmail.setText(String.valueOf(tableModel.getValueAt(r, 4)));
            }
        });

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        setLayout(new BorderLayout(10, 10));
        add(top, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refreshTable();
    }

    private Doctor readDoctorFromForm() {
        Doctor d = new Doctor();
        d.setDoctorId(txtId.getText().trim());
        d.setName(txtName.getText().trim());
        d.setSpeciality(txtSpeciality.getText().trim());
        d.setPhone(txtPhone.getText().trim());
        d.setEmail(txtEmail.getText().trim());
        return d;
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Doctor> list = doctorController.getAllDoctors();
        for (Doctor d : list) {
            tableModel.addRow(new Object[]{
                    d.getDoctorId(), d.getName(), d.getSpeciality(), d.getPhone(), d.getEmail()
            });
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtSpeciality.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        table.clearSelection();
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
