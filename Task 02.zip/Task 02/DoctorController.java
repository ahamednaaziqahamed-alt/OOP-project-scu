package medicare.controller;

import medicare.model.Doctor;
import medicare.store.DataStore;

import java.util.ArrayList;
import java.util.List;

public class DoctorController {

    public List<Doctor> getAllDoctors() {
        return new ArrayList<>(DataStore.doctors);
    }

    public Doctor findById(String doctorId) {
        if (doctorId == null) return null;
        for (Doctor d : DataStore.doctors) {
            if (doctorId.equals(d.getDoctorId())) return d;
        }
        return null;
    }

    public void addDoctor(Doctor doctor) {
        if (doctor == null) throw new IllegalArgumentException("Doctor is required");
        validateDoctor(doctor);

        if (findById(doctor.getDoctorId()) != null) {
            throw new IllegalStateException("Doctor ID already exists");
        }
        DataStore.doctors.add(doctor);
    }

    public void updateDoctor(Doctor updated) {
        if (updated == null) throw new IllegalArgumentException("Doctor is required");
        validateDoctor(updated);

        Doctor existing = findById(updated.getDoctorId());
        if (existing == null) throw new IllegalStateException("Doctor not found");

        existing.setName(updated.getName());
        existing.setSpeciality(updated.getSpeciality());
        existing.setPhone(updated.getPhone());
        existing.setEmail(updated.getEmail());
    }

    public void deleteDoctor(String doctorId) {
        Doctor existing = findById(doctorId);
        if (existing == null) throw new IllegalStateException("Doctor not found");
        DataStore.doctors.remove(existing);
    }

    public List<String> getAllSpecialities() {
        List<String> out = new ArrayList<>();
        for (Doctor d : DataStore.doctors) {
            String sp = d.getSpeciality();
            if (sp != null && !sp.trim().isEmpty() && !out.contains(sp)) out.add(sp);
        }
        return out;
    }

    private void validateDoctor(Doctor d) {
        if (isBlank(d.getDoctorId())) throw new IllegalArgumentException("Doctor ID required");
        if (isBlank(d.getName())) throw new IllegalArgumentException("Doctor name required");
        if (isBlank(d.getSpeciality())) throw new IllegalArgumentException("Speciality required");
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
