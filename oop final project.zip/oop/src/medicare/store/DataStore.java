package medicare.store;

import medicare.model.Appointment;
import medicare.model.Doctor;
import medicare.model.Notification;
import medicare.model.Patient;

import java.util.ArrayList;
import java.util.List;

public final class DataStore {

    // In-memory lists (no DB). App closes => data gone.
    public static final List<Patient> patients = new ArrayList<>();
    public static final List<Doctor> doctors = new ArrayList<>();
    public static final List<Appointment> appointments = new ArrayList<>();
    public static final List<Notification> notifications = new ArrayList<>();

    private DataStore() {
        // prevent instantiation
    }
}
