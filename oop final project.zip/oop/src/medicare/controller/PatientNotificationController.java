package medicare.controller;

import medicare.model.Notification;
import medicare.store.DataStore;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PatientNotificationController {

    public void notifyPatient(String patientId, String message) {
        if (isBlank(patientId)) throw new IllegalArgumentException("Patient ID required");
        if (isBlank(message)) throw new IllegalArgumentException("Message required");

        Notification n = new Notification();
        n.setNotificationId(generateId("PN"));
        n.setRecipientType("PATIENT");
        n.setRecipientId(patientId);
        n.setMessage(message);
        n.setCreatedAt(LocalDateTime.now());
        n.setRead(false);

        DataStore.notifications.add(n);
    }

    public List<Notification> getPatientNotifications(String patientId) {
        List<Notification> out = new ArrayList<>();
        if (patientId == null) return out;

        for (Notification n : DataStore.notifications) {
            if ("PATIENT".equals(n.getRecipientType()) && patientId.equals(n.getRecipientId())) {
                out.add(n);
            }
        }
        return out;
    }

    public void markAsRead(String notificationId) {
        for (Notification n : DataStore.notifications) {
            if (notificationId != null && notificationId.equals(n.getNotificationId())) {
                n.setRead(true);
                return;
            }
        }
        throw new IllegalStateException("Notification not found");
    }

    private String generateId(String prefix) {
        return prefix + "-" + System.currentTimeMillis();
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
