
package medicare.app;

import medicare.view.MainMenuView;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            SeedData.seedOnce(); // add this

            new MainMenuView().setVisible(true);
        });
    }
}
