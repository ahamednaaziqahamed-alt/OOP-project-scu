package medicare.view;

import javax.swing.*;
import java.awt.*;

public class MainMenuView extends JFrame {

    public MainMenuView() {
        setTitle("MediCare Plus - Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 520);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnPatients = new JButton("Manage Patients");
        JButton btnDoctors = new JButton("Manage Doctors");
        JButton btnSchedule = new JButton("Schedule Appointment");
        JButton btnTrack = new JButton("Track Appointment Status");
        JButton btnAssign = new JButton("Assign Doctor to Patient");
        JButton btnReport = new JButton("Monthly Report");
        JButton btnPatientNoti = new JButton("Patient Notifications");
        JButton btnDoctorNoti = new JButton("Doctor Notifications");
        JButton btnExit = new JButton("Exit");

        btnPatients.addActionListener(e -> new ManagePatientsView().setVisible(true));
        btnDoctors.addActionListener(e -> new ManageDoctorsView().setVisible(true));
        btnSchedule.addActionListener(e -> new ScheduleAppointmentView().setVisible(true));
        btnTrack.addActionListener(e -> new TrackAppointmentStatusView().setVisible(true));
        btnAssign.addActionListener(e -> new AssignDoctorView().setVisible(true));
        btnReport.addActionListener(e -> new MonthlyReportView().setVisible(true));
        btnPatientNoti.addActionListener(e -> new PatientNotificationsView().setVisible(true));
        btnDoctorNoti.addActionListener(e -> new DoctorNotificationsView().setVisible(true));
        btnExit.addActionListener(e -> dispose());

        panel.add(btnPatients);
        panel.add(btnDoctors);
        panel.add(btnSchedule);
        panel.add(btnTrack);
        panel.add(btnAssign);
        panel.add(btnReport);
        panel.add(btnPatientNoti);
        panel.add(btnDoctorNoti);
        panel.add(btnExit);

        setContentPane(panel);
    }
}
