package medicare.view;

import medicare.controller.DoctorController;
import medicare.controller.DoctorNotificationController;
import medicare.model.Doctor;
import medicare.model.Notification;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DoctorNotificationsView extends JFrame {

    private final DoctorController doctorController = new DoctorController();
    private final DoctorNotificationController notificationController = new DoctorNotificationController();

    private final JComboBox<String> cmbDoctorId = new JComboBox<>();
    private final JTextField txtMessage = new JTextField();

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Notification ID", "Message", "Created At", "Read"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    public DoctorNotificationsView() {
        setTitle("Doctor Notifications");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(950, 520);
        setLocationRelativeTo(null);

        // ---------- Form ----------
        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Send Notification"));

        form.add(new JLabel("Doctor"));
        form.add(cmbDoctorId);

        form.add(new JLabel("Message"));
        form.add(txtMessage);

        // ---------- Buttons ----------
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnSend = new JButton("Send");
        JButton btnLoad = new JButton("Load");
        JButton btnMarkRead = new JButton("Mark Selected As Read");
        JButton btnClear = new JButton("Clear");
        JButton btnBack = new JButton("Back");

        buttons.add(btnSend);
        buttons.add(btnLoad);
        buttons.add(btnMarkRead);
        buttons.add(btnClear);
        buttons.add(btnBack);

        // ---------- Top container ----------
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBorder(new EmptyBorder(10, 10, 10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        // ---------- Table ----------
        table.setRowHeight(26);
        table.getTableHeader().setReorderingAllowed(false);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder("Notifications"));

        // ---------- Layout ----------
        setLayout(new BorderLayout(10, 10));
        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        // ---------- Actions ----------
        btnSend.addActionListener(e -> sendNotification());
        btnLoad.addActionListener(e -> refreshTable());

        btnMarkRead.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) {
                error("Select a notification row first.");
                return;
            }
            try {
                String id = String.valueOf(model.getValueAt(r, 0));
                notificationController.markAsRead(id);
                refreshTable();
                info("Marked as read.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnClear.addActionListener(e -> {
            txtMessage.setText("");
            table.clearSelection();
        });

        btnBack.addActionListener(e -> dispose());

        cmbDoctorId.addActionListener(e -> refreshTable());

        // ---------- Init ----------
        loadDoctors();
        refreshTable();
    }

    private void sendNotification() {
        try {
            String did = (String) cmbDoctorId.getSelectedItem();
            String msg = txtMessage.getText().trim();

            if (did == null || did.trim().isEmpty()) {
                throw new IllegalArgumentException("Select a doctor first.");
            }
            if (msg.isEmpty()) {
                throw new IllegalArgumentException("Message cannot be empty.");
            }

            notificationController.notifyDoctor(did, msg);
            txtMessage.setText("");
            refreshTable();
            info("Notification sent.");
        } catch (Exception ex) {
            error(ex.getMessage());
        }
    }

    private void loadDoctors() {
        cmbDoctorId.removeAllItems();
        for (Doctor d : doctorController.getAllDoctors()) {
            cmbDoctorId.addItem(d.getDoctorId());
        }
    }

    private void refreshTable() {
        model.setRowCount(0);

        String did = (String) cmbDoctorId.getSelectedItem();
        if (did == null) return;

        List<Notification> list = notificationController.getDoctorNotifications(did);
        for (Notification n : list) {
            model.addRow(new Object[]{
                    n.getNotificationId(),
                    n.getMessage(),
                    n.getCreatedAt(),
                    n.isRead()
            });
        }
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
