package medicare.view;

import medicare.controller.AssignDoctorController;
import medicare.controller.DoctorController;
import medicare.controller.PatientController;
import medicare.model.Doctor;
import medicare.model.Patient;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AssignDoctorView extends JFrame {

    private final AssignDoctorController assignController = new AssignDoctorController();
    private final PatientController patientController = new PatientController();
    private final DoctorController doctorController = new DoctorController();

    private final JComboBox<String> cmbPatientId = new JComboBox<>();
    private final JTextField txtSpeciality = new JTextField();
    private final JTextField txtDate = new JTextField("2025-12-14");
    private final JTextField txtTime = new JTextField("10:30");
    private final JTextField txtAssignedDoctor = new JTextField();

    public AssignDoctorView() {
        setTitle("Assign Doctor to Patient");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 360);
        setLocationRelativeTo(null);

        txtAssignedDoctor.setEditable(false);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(new JLabel("Patient"));
        form.add(cmbPatientId);

        form.add(new JLabel("Required Speciality"));
        form.add(txtSpeciality);

        form.add(new JLabel("Preferred Date (yyyy-MM-dd)"));
        form.add(txtDate);

        form.add(new JLabel("Preferred Time (HH:mm)"));
        form.add(txtTime);

        form.add(new JLabel("Assigned Doctor ID"));
        form.add(txtAssignedDoctor);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnAutoAssign = new JButton("Auto Assign");
        JButton btnList = new JButton("Show Doctors by Speciality");
        JButton btnBack = new JButton("Back");

        buttons.add(btnAutoAssign);
        buttons.add(btnList);
        buttons.add(btnBack);

        btnAutoAssign.addActionListener(e -> {
            try {
                String speciality = txtSpeciality.getText().trim();
                LocalDate date = LocalDate.parse(txtDate.getText().trim());
                LocalTime time = LocalTime.parse(txtTime.getText().trim());

                Doctor assigned = assignController.autoAssignDoctor(speciality, date, time);
                if (assigned == null) {
                    txtAssignedDoctor.setText("");
                    error("No available doctor found for that speciality/date/time.");
                    return;
                }
                txtAssignedDoctor.setText(assigned.getDoctorId());
                info("Assigned Doctor: " + assigned.getDoctorId());
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnList.addActionListener(e -> {
            String speciality = txtSpeciality.getText().trim();
            List<Doctor> docs = assignController.getDoctorsBySpeciality(speciality);
            if (docs.isEmpty()) {
                info("No doctors found for speciality: " + speciality);
                return;
            }
            StringBuilder sb = new StringBuilder("Doctors (" + speciality + ")\n\n");
            for (Doctor d : docs) {
                sb.append(d.getDoctorId()).append(" - ").append(d.getName()).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString(), "Doctors", JOptionPane.INFORMATION_MESSAGE);
        });

        btnBack.addActionListener(e -> dispose());

        setLayout(new BorderLayout());
        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        loadPatients();
    }

    private void loadPatients() {
        cmbPatientId.removeAllItems();
        for (Patient p : patientController.getAllPatients()) {
            cmbPatientId.addItem(p.getPatientId());
        }
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
