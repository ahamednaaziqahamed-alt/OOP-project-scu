package medicare.view;

import medicare.controller.PatientController;
import medicare.model.Patient;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ManagePatientsView extends JFrame {

    private final PatientController patientController = new PatientController();

    private final JTextField txtId = new JTextField();
    private final JTextField txtName = new JTextField();
    private final JTextField txtNic = new JTextField();
    private final JTextField txtPhone = new JTextField();
    private final JTextField txtEmail = new JTextField();
    private final JTextField txtAddress = new JTextField();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Patient ID", "Name", "NIC", "Phone", "Email", "Address"}, 0
    );
    private final JTable table = new JTable(tableModel);

    public ManagePatientsView() {
        setTitle("Manage Patients");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(950, 550);
        setLocationRelativeTo(null);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Patient Details"));

        form.add(new JLabel("Patient ID"));
        form.add(txtId);
        form.add(new JLabel("Name"));
        form.add(txtName);
        form.add(new JLabel("NIC"));
        form.add(txtNic);
        form.add(new JLabel("Phone"));
        form.add(txtPhone);
        form.add(new JLabel("Email"));
        form.add(txtEmail);
        form.add(new JLabel("Address"));
        form.add(txtAddress);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");
        JButton btnBack = new JButton("Back");

        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        buttons.add(btnBack);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Patients List"));

        btnAdd.addActionListener(e -> {
            try {
                Patient p = readPatientFromForm();
                patientController.addPatient(p);
                refreshTable();
                clearForm();
                info("Patient added.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                Patient p = readPatientFromForm();
                patientController.updatePatient(p);
                refreshTable();
                info("Patient updated.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                String id = txtId.getText().trim();
                patientController.deletePatient(id);
                refreshTable();
                clearForm();
                info("Patient deleted.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnClear.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                txtName.setText(String.valueOf(tableModel.getValueAt(r, 1)));
                txtNic.setText(String.valueOf(tableModel.getValueAt(r, 2)));
                txtPhone.setText(String.valueOf(tableModel.getValueAt(r, 3)));
                txtEmail.setText(String.valueOf(tableModel.getValueAt(r, 4)));
                txtAddress.setText(String.valueOf(tableModel.getValueAt(r, 5)));
            }
        });

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        setLayout(new BorderLayout(10, 10));
        add(top, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refreshTable();
    }

    private Patient readPatientFromForm() {
        Patient p = new Patient();
        p.setPatientId(txtId.getText().trim());
        p.setName(txtName.getText().trim());
        p.setNic(txtNic.getText().trim());
        p.setPhone(txtPhone.getText().trim());
        p.setEmail(txtEmail.getText().trim());
        p.setAddress(txtAddress.getText().trim());
        return p;
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Patient> list = patientController.getAllPatients();
        for (Patient p : list) {
            tableModel.addRow(new Object[]{
                    p.getPatientId(), p.getName(), p.getNic(), p.getPhone(), p.getEmail(), p.getAddress()
            });
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtNic.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        table.clearSelection();
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
