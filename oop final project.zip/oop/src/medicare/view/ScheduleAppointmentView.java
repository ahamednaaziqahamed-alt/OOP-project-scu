package medicare.view;

import medicare.controller.*;
import medicare.model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class ScheduleAppointmentView extends JFrame {

    private final AppointmentController appointmentController = new AppointmentController();
    private final PatientController patientController = new PatientController();
    private final DoctorController doctorController = new DoctorController();

    private final JTextField txtAppointmentId = new JTextField();
    private final JComboBox<String> cmbPatientId = new JComboBox<>();
    private final JComboBox<String> cmbDoctorId = new JComboBox<>();
    private final JTextField txtDate = new JTextField("2025-12-14"); // yyyy-MM-dd
    private final JTextField txtTime = new JTextField("10:30");      // HH:mm
    private final JTextField txtReason = new JTextField();
    private final JComboBox<AppointmentStatus> cmbStatus = new JComboBox<>(AppointmentStatus.values());
    private final JTextField txtRemarks = new JTextField();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Appt ID", "Patient", "Doctor", "Date", "Time", "Status"}, 0
    );
    private final JTable table = new JTable(tableModel);

    public ScheduleAppointmentView() {
        setTitle("Schedule Appointment");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1050, 560);
        setLocationRelativeTo(null);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Appointment Details"));

        form.add(new JLabel("Appointment ID"));
        form.add(txtAppointmentId);

        form.add(new JLabel("Patient"));
        form.add(cmbPatientId);

        form.add(new JLabel("Doctor"));
        form.add(cmbDoctorId);

        form.add(new JLabel("Date (yyyy-MM-dd)"));
        form.add(txtDate);

        form.add(new JLabel("Time (HH:mm)"));
        form.add(txtTime);

        form.add(new JLabel("Reason"));
        form.add(txtReason);

        form.add(new JLabel("Status"));
        form.add(cmbStatus);

        form.add(new JLabel("Remarks"));
        form.add(txtRemarks);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnAdd = new JButton("Schedule");
        JButton btnUpdate = new JButton("Update");
        JButton btnCancel = new JButton("Cancel");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");
        JButton btnBack = new JButton("Back");

        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnCancel);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        buttons.add(btnBack);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Appointments"));

        btnAdd.addActionListener(e -> {
            try {
                Appointment a = readAppointment();
                appointmentController.scheduleAppointment(a);
                refreshTable();
                clearForm();
                info("Appointment scheduled.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                Appointment a = readAppointment();
                appointmentController.updateAppointment(a);
                refreshTable();
                info("Appointment updated.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnCancel.addActionListener(e -> {
            try {
                String id = txtAppointmentId.getText().trim();
                appointmentController.cancelAppointment(id, txtRemarks.getText().trim());
                refreshTable();
                info("Appointment cancelled.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                String id = txtAppointmentId.getText().trim();
                appointmentController.deleteAppointment(id);
                refreshTable();
                clearForm();
                info("Appointment deleted.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnClear.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtAppointmentId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                cmbPatientId.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 1)));
                cmbDoctorId.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 2)));
                txtDate.setText(String.valueOf(tableModel.getValueAt(r, 3)));
                txtTime.setText(String.valueOf(tableModel.getValueAt(r, 4)));
                cmbStatus.setSelectedItem(AppointmentStatus.valueOf(String.valueOf(tableModel.getValueAt(r, 5))));
            }
        });

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        setLayout(new BorderLayout(10, 10));
        add(top, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        loadCombos();
        refreshTable();
    }

    private void loadCombos() {
        cmbPatientId.removeAllItems();
        for (Patient p : patientController.getAllPatients()) {
            cmbPatientId.addItem(p.getPatientId());
        }

        cmbDoctorId.removeAllItems();
        for (Doctor d : doctorController.getAllDoctors()) {
            cmbDoctorId.addItem(d.getDoctorId());
        }
    }

    private Appointment readAppointment() {
        Appointment a = new Appointment();
        a.setAppointmentId(txtAppointmentId.getText().trim());
        a.setPatientId((String) cmbPatientId.getSelectedItem());
        a.setDoctorId((String) cmbDoctorId.getSelectedItem());
        a.setDate(LocalDate.parse(txtDate.getText().trim()));
        a.setTime(LocalTime.parse(txtTime.getText().trim()));
        a.setReason(txtReason.getText().trim());
        a.setStatus((AppointmentStatus) cmbStatus.getSelectedItem());
        a.setRemarks(txtRemarks.getText().trim());
        return a;
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Appointment> list = appointmentController.getAllAppointments();
        for (Appointment a : list) {
            tableModel.addRow(new Object[]{
                    a.getAppointmentId(),
                    a.getPatientId(),
                    a.getDoctorId(),
                    a.getDate(),
                    a.getTime(),
                    a.getStatus()
            });
        }
        loadCombos();
    }

    private void clearForm() {
        txtAppointmentId.setText("");
        txtReason.setText("");
        txtRemarks.setText("");
        table.clearSelection();
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
