package medicare.view;

import medicare.controller.MonthlyReportController;
import medicare.model.AppointmentStatus;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.YearMonth;
import java.util.Map;

public class MonthlyReportView extends JFrame {

    private final MonthlyReportController controller = new MonthlyReportController();

    private final JTextField txtMonth = new JTextField(10); // YYYY-MM
    private final JLabel lblTotal = new JLabel("0");
    private final JLabel lblUniquePatients = new JLabel("0");
    private final JLabel lblUniqueDoctors = new JLabel("0");

    private final DefaultTableModel statusModel = new DefaultTableModel(
            new Object[]{"Status", "Count"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblStatus = new JTable(statusModel);

    public MonthlyReportView() {
        setTitle("Monthly Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(820, 520);
        setLocationRelativeTo(null);

        // ---------- Top controls ----------
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        controls.setBorder(new EmptyBorder(10, 10, 0, 10));

        txtMonth.setText(YearMonth.now().toString()); // auto-fill

        JButton btnGenerate = new JButton("Generate");
        JButton btnBack = new JButton("Back");

        controls.add(new JLabel("Month (YYYY-MM):"));
        controls.add(txtMonth);
        controls.add(btnGenerate);
        controls.add(btnBack);

        // ---------- Summary "cards" ----------
        JPanel summary = new JPanel(new GridLayout(1, 3, 12, 12));
        summary.setBorder(new EmptyBorder(10, 10, 10, 10));

        summary.add(card("Total Appointments", lblTotal));
        summary.add(card("Unique Patients", lblUniquePatients));
        summary.add(card("Unique Doctors", lblUniqueDoctors));

        // ---------- Status table ----------
        tblStatus.setRowHeight(26);
        tblStatus.getTableHeader().setReorderingAllowed(false);

        JScrollPane sp = new JScrollPane(tblStatus);
        sp.setBorder(BorderFactory.createTitledBorder("Status Summary"));

        // ---------- Main layout ----------
        JPanel top = new JPanel(new BorderLayout());
        top.add(controls, BorderLayout.NORTH);
        top.add(summary, BorderLayout.CENTER);

        setLayout(new BorderLayout());
        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);

        // ---------- Actions ----------
        btnGenerate.addActionListener(e -> generate());
        btnBack.addActionListener(e -> dispose());

        // Pre-load once
        generate();
    }

    private JPanel card(String title, JLabel value) {
        value.setFont(value.getFont().deriveFont(Font.BOLD, 22f));

        JLabel t = new JLabel(title);
        t.setFont(t.getFont().deriveFont(Font.PLAIN, 13f));

        JPanel p = new JPanel(new BorderLayout(6, 6));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                new EmptyBorder(10, 12, 10, 12)
        ));
        p.add(t, BorderLayout.NORTH);
        p.add(value, BorderLayout.CENTER);
        return p;
    }

    private void generate() {
        try {
            YearMonth ym = YearMonth.parse(txtMonth.getText().trim());

            lblTotal.setText(String.valueOf(controller.getTotalAppointments(ym)));
            lblUniquePatients.setText(String.valueOf(controller.getUniquePatients(ym)));
            lblUniqueDoctors.setText(String.valueOf(controller.getUniqueDoctors(ym)));

            statusModel.setRowCount(0);
            Map<AppointmentStatus, Integer> map = controller.getStatusSummary(ym);
            for (AppointmentStatus s : AppointmentStatus.values()) {
                statusModel.addRow(new Object[]{s.name(), map.getOrDefault(s, 0)});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Invalid month. Use format YYYY-MM (example: 2025-12).",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
