package medicare.view;

import medicare.controller.TrackAppointmentStatusController;
import medicare.model.Appointment;
import medicare.model.AppointmentStatus;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TrackAppointmentStatusView extends JFrame {

    private final TrackAppointmentStatusController controller = new TrackAppointmentStatusController();

    private final JTextField txtAppointmentId = new JTextField();
    private final JComboBox<AppointmentStatus> cmbStatus = new JComboBox<>(AppointmentStatus.values());
    private final JTextField txtRemarks = new JTextField();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Appt ID", "Patient", "Doctor", "Date", "Time", "Status", "Remarks"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // prevent editing in table
        }
    };

    private final JTable table = new JTable(tableModel);

    public TrackAppointmentStatusView() {
        setTitle("Track Appointment Status");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1100, 600);
        setLocationRelativeTo(null);

        // --------- Form Panel ----------
        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Update Status"));

        form.add(new JLabel("Appointment ID"));
        form.add(txtAppointmentId);

        form.add(new JLabel("Status"));
        form.add(cmbStatus);

        form.add(new JLabel("Remarks"));
        form.add(txtRemarks);

        // --------- Buttons ----------
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton btnLoad = new JButton("Load");
        JButton btnUpdate = new JButton("Update Status");
        JButton btnDelete = new JButton("Delete Appointment");
        JButton btnClear = new JButton("Clear");
        JButton btnBack = new JButton("Back");

        buttons.add(btnLoad);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        buttons.add(btnBack);

        // --------- Top Container (Form + Buttons) ----------
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        // --------- Table ----------
        table.setRowHeight(24);
        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Appointments"));

        // --------- Actions ----------
        btnLoad.addActionListener(e -> {
            String apptId = txtAppointmentId.getText().trim();
            Appointment a = controller.loadAppointment(apptId);
            if (a == null) {
                error("Appointment not found. Use an Appointment ID like A001, not Patient ID.");
                return;
            }
            cmbStatus.setSelectedItem(a.getStatus());
            txtRemarks.setText(a.getRemarks());
        });

        btnUpdate.addActionListener(e -> {
            try {
                controller.updateStatus(
                        txtAppointmentId.getText().trim(),
                        (AppointmentStatus) cmbStatus.getSelectedItem(),
                        txtRemarks.getText().trim()
                );
                refreshTable();
                info("Status updated.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                controller.deleteAppointment(txtAppointmentId.getText().trim());
                refreshTable();
                clearForm();
                info("Appointment deleted.");
            } catch (Exception ex) {
                error(ex.getMessage());
            }
        });

        btnClear.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtAppointmentId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                cmbStatus.setSelectedItem(AppointmentStatus.valueOf(String.valueOf(tableModel.getValueAt(r, 5))));
                txtRemarks.setText(String.valueOf(tableModel.getValueAt(r, 6)));
            }
        });

        // --------- Layout ----------
        setLayout(new BorderLayout(10, 10));
        add(top, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Appointment> list = controller.getAllAppointments();
        for (Appointment a : list) {
            tableModel.addRow(new Object[]{
                    a.getAppointmentId(),
                    a.getPatientId(),
                    a.getDoctorId(),
                    a.getDate(),
                    a.getTime(),
                    a.getStatus(),
                    a.getRemarks()
            });
        }
    }

    private void clearForm() {
        txtAppointmentId.setText("");
        txtRemarks.setText("");
        table.clearSelection();
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
