package medicare.model;

import java.time.LocalDateTime;

public class Notification {

    private String notificationId;

    // "PATIENT" or "DOCTOR"
    private String recipientType;

    // patientId or doctorId depending on type
    private String recipientId;

    private String message;
    private LocalDateTime createdAt;

    private boolean isRead;

    public Notification() {}

    public Notification(String notificationId, String recipientType, String recipientId,
                        String message, LocalDateTime createdAt, boolean isRead) {
        this.notificationId = notificationId;
        this.recipientType = recipientType;
        this.recipientId = recipientId;
        this.message = message;
        this.createdAt = createdAt;
        this.isRead = isRead;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getRecipientType() {
        return recipientType;
    }

    public void setRecipientType(String recipientType) {
        this.recipientType = recipientType;
    }

    public String getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }
}
