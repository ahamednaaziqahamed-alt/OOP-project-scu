package medicare.controller;

import medicare.model.Notification;
import medicare.store.DataStore;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DoctorNotificationController {

    public void notifyDoctor(String doctorId, String message) {
        if (isBlank(doctorId)) throw new IllegalArgumentException("Doctor ID required");
        if (isBlank(message)) throw new IllegalArgumentException("Message required");

        Notification n = new Notification();
        n.setNotificationId(generateId("DN"));
        n.setRecipientType("DOCTOR");
        n.setRecipientId(doctorId);
        n.setMessage(message);
        n.setCreatedAt(LocalDateTime.now());
        n.setRead(false);

        DataStore.notifications.add(n);
    }

    public List<Notification> getDoctorNotifications(String doctorId) {
        List<Notification> out = new ArrayList<>();
        if (doctorId == null) return out;

        for (Notification n : DataStore.notifications) {
            if ("DOCTOR".equals(n.getRecipientType()) && doctorId.equals(n.getRecipientId())) {
                out.add(n);
            }
        }
        return out;
    }

    public void markAsRead(String notificationId) {
        for (Notification n : DataStore.notifications) {
            if (notificationId != null && notificationId.equals(n.getNotificationId())) {
                n.setRead(true);
                return;
            }
        }
        throw new IllegalStateException("Notification not found");
    }

    private String generateId(String prefix) {
        return prefix + "-" + System.currentTimeMillis();
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
