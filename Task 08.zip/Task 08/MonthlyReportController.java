package medicare.controller;

import medicare.model.Appointment;
import medicare.model.AppointmentStatus;
import medicare.store.DataStore;

import java.time.YearMonth;
import java.util.*;

public class MonthlyReportController {

    public int getTotalAppointments(YearMonth month) {
        int count = 0;
        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) count++;
        }
        return count;
    }

    public int getUniquePatients(YearMonth month) {
        Set<String> set = new HashSet<>();
        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) {
                if (a.getPatientId() != null) set.add(a.getPatientId());
            }
        }
        return set.size();
    }

    public int getUniqueDoctors(YearMonth month) {
        Set<String> set = new HashSet<>();
        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) {
                if (a.getDoctorId() != null) set.add(a.getDoctorId());
            }
        }
        return set.size();
    }

    // Status -> Count
    public Map<AppointmentStatus, Integer> getStatusSummary(YearMonth month) {
        Map<AppointmentStatus, Integer> map = new EnumMap<>(AppointmentStatus.class);
        for (AppointmentStatus s : AppointmentStatus.values()) map.put(s, 0);

        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) {
                AppointmentStatus s = a.getStatus();
                if (s != null) map.put(s, map.get(s) + 1);
            }
        }
        return map;
    }

    // DoctorId -> Completed Count
    public Map<String, Integer> getDoctorPerformance(YearMonth month) {
        Map<String, Integer> map = new HashMap<>();
        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) {
                if (a.getStatus() == AppointmentStatus.COMPLETED) {
                    map.put(a.getDoctorId(), map.getOrDefault(a.getDoctorId(), 0) + 1);
                }
            }
        }
        return map;
    }

    // PatientId -> Visit Count
    public Map<String, Integer> getPatientVisits(YearMonth month) {
        Map<String, Integer> map = new HashMap<>();
        for (Appointment a : DataStore.appointments) {
            if (a.getDate() != null && YearMonth.from(a.getDate()).equals(month)) {
                map.put(a.getPatientId(), map.getOrDefault(a.getPatientId(), 0) + 1);
            }
        }
        return map;
    }
}
